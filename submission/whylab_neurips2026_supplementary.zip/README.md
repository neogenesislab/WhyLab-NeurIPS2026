# WhyLab: Supplementary Code

## Structure
- `experiments/` - All experiment scripts (E1-E5)
- `experiments/results/` - Pre-computed results (CSV)
- `experiments/prompts/` - LLM prompts for E4/E5
- `experiments/config.yaml` - Experiment configuration

## Reproduction
```bash
pip install numpy pandas scipy pyyaml datasets google-generativeai
# Set GEMINI_API_KEY in .env or environment
python -m experiments.e1_drift_detection
python -m experiments.e3a_stability
python -m experiments.e5_swebench_benchmark --pilot
```
